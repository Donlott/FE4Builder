# リアル戦闘モーション - Real combat motion

Category: weapons

Target: FE4

Source: `FE4 ツール、資料系 - Tools, Reference Materials/バグフォグラムズ資料 - Bugfograms material/画像関連 - Image related/リアル戦闘モーション - Real combat motion`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 05_Battle_animations/P109_Real_combat_motion, 07_Battle_weapons_and_shields/P109_Real_combat_motion
