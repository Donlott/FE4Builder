# FE4 トラ7武器移植パッチ - FE4 Tora 7 weapon port patch

Category: weapons

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/聖戦用パッチ・素材集 - Holy war patch-material collection/パッチ - patch/FE4 トラ7武器移植パッチ - FE4 Tora 7 weapon port patch`

Installation patch may change tables/code as well as graphics; inspect patch footprint.

No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 07_Battle_weapons_and_shields/P042_FE4_Tora_7_weapon_port_patch
