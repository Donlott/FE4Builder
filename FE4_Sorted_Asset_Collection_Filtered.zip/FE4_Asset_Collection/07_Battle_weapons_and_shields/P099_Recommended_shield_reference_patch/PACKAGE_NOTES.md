# 盾参考パッチのすすめ - Recommended shield reference patch

Category: weapons

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/聖戦用パッチ・素材集 - Holy war patch-material collection/テキスト - text/盾参考パッチのすすめ - Recommended shield reference patch`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 07_Battle_weapons_and_shields/P099_Recommended_shield_reference_patch
