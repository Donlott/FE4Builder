# FE4-リアル戦闘武器グラパレット - FE4-Real Combat Weapon Grapalette

Category: weapons

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4-リアル戦闘武器グラパレット - FE4-Real Combat Weapon Grapalette`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 07_Battle_weapons_and_shields/P135_FE4-Real_Combat_Weapon_Grapalette
