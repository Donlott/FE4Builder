# ベルサガドット絵 - Bersaga dot picture

Category: portraits

Target: FE4_or_FE5_check_readme

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4,5 顔グラ画像系 - FE4,5 Face graph image system/ベルサガドット絵 - Bersaga dot picture`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 01_Portraits/P015_Bersaga_dot_picture
