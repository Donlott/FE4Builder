# 聖戦・トラキア用顔グラ（リーフ他） - Face graphics for Holy War-Thracia (leaf etc.)

Category: portraits

Target: FE4_or_FE5_check_readme

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4,5 顔グラ画像系 - FE4,5 Face graph image system/聖戦・トラキア用顔グラ（リーフ他） - Face graphics for Holy War-Thracia (leaf etc.)`



- Shared portrait palette compatibility requires checking

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 01_Portraits/P018_Face_graphics_for_Holy_War-Thracia_leaf_et

## Reviewed Japanese-readme finding

Leif and other portraits: the author requires disabling the common portrait palette for FE4. A related optional unlock patch has been placed beside this pack.
