# FE4 アネット - FE4 Annette

Category: portraits

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4,5 顔グラ画像系 - FE4,5 Face graph image system/FE4 アネット - FE4 Annette`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 01_Portraits/P014_FE4_Annette

## Reviewed Japanese-readme finding

FEH Annette: readme explicitly targets FE4. Raw/compressed images and palettes are retained.
