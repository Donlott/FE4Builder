# 聖戦用GBA移植雑魚顔 - GBA ported small fry face for holy war

Category: portraits

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/聖戦用パッチ・素材集 - Holy war patch-material collection/画像 - image/聖戦用GBA移植雑魚顔 - GBA ported small fry face for holy war`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 01_Portraits/P049_GBA_ported_small_fry_face_for_holy_war
