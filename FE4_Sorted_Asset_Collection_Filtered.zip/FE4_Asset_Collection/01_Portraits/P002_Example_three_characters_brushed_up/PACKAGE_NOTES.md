# 例の三キャラ+α ブラシュアップ済 - Example three characters +α brushed up

Category: portraits

Target: FE4_or_FE5_check_readme

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4,5 顔グラ画像系 - FE4,5 Face graph image system/例の三キャラ+α ブラシュアップ済 - Example three characters +α brushed up`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 01_Portraits/P002_Example_three_characters_brushed_up
