# GBAキャラ移植ver2.0 - GBA character port ver2.0

Category: portraits

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4,5 顔グラ画像系 - FE4,5 Face graph image system/GBAキャラ移植ver2.0 - GBA character port ver2.0`



- Copier-header requirement mentioned

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 01_Portraits/P009_GBA_character_port_ver2.0

## Reviewed Japanese-readme finding

GBA portraits: the Japanese readme explicitly documents .bmp as 48x64 or 128x32, .smc as raw pixels, .chr as palette, and .bin as compressed pixels. Manual data insertion plus two pointers is required; source addresses are headered.
