# FE4ラケシスFEH化 - FE4 Lachesis FEH conversion

Category: portraits

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4,5 顔グラ画像系 - FE4,5 Face graph image system/FE4ラケシスFEH化 - FE4 Lachesis FEH conversion`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 01_Portraits/P011_FE4_Lachesis_FEH_conversion

## Reviewed Japanese-readme finding

FEH Lachesis: the author says the compressed portrait is larger than its original slot and cannot overwrite that allocation directly.
