# FE engage - FE engage

Category: portraits

Target: FE4_or_FE5_check_readme

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4,5 顔グラ画像系 - FE4,5 Face graph image system/FE engage - FE engage`



- Author says untested

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 01_Portraits/P006_FE_engage

## Reviewed Japanese-readme finding

Engage portrait: the author explicitly says to compress and insert, and that operation is untested.
