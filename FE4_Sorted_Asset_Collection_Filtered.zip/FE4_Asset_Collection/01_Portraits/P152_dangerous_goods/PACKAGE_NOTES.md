# 危険物 - dangerous goods

Category: portraits

Target: FE4

Source: `FE4 二次創作系パッチ - Fan Made Hacks/東方の系譜ver112 - Touhou genealogy ver112/危険物 - dangerous goods`

Loose asset from a full hack. The full-hack IPS is deliberately not an asset installer.

No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 01_Portraits/P152_dangerous_goods

## Reviewed Japanese-readme finding

Touhou hack loose portrait: the supplied binary, palette and bitmap are retained. The whole Touhou hack IPS is deliberately not attached as a portrait installer.
