# 市民革命パッチ - citizen revolution patch

Category: portraits

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4,5 顔グラ画像系 - FE4,5 Face graph image system/市民革命パッチ - citizen revolution patch`



- Unmodified ROM requirement/recommendation mentioned

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 01_Portraits/P019_citizen_revolution_patch
