# 移動アイコン - move icon

Category: movement

Target: FE4

Source: `FE4 ツール、資料系 - Tools, Reference Materials/バグフォグラムズ資料 - Bugfograms material/画像関連 - Image related/移動アイコン - move icon`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 03_Map_movement/P113_move_icon
