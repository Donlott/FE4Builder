# アイコン移植 - Icon porting

Category: movement

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4,5 マップアニメ画像系 - FE4,5 map anime image system/アイコン移植 - Icon porting`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 02_Map_combat/P033_Icon_porting, 03_Map_movement/P033_Icon_porting, 04_Map_standing_icons/P033_Icon_porting

## Reviewed Japanese-readme finding

Icon porting: the readme describes direct insertion/pointer changes, a split-bank placement issue, and the axe-fighter upper-right control header fix. Graphics alone are not sufficient in every case.
