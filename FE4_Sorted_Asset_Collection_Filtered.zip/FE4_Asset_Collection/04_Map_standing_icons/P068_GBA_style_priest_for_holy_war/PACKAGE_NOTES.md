# 聖戦用GBA風司祭 - GBA style priest for holy war

Category: standing

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/聖戦用パッチ・素材集 - Holy war patch-material collection/画像 - image/聖戦用GBA風司祭 - GBA style priest for holy war`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 05_Battle_animations/P068_GBA_style_priest_for_holy_war, 02_Map_combat/P068_GBA_style_priest_for_holy_war, 03_Map_movement/P068_GBA_style_priest_for_holy_war, 04_Map_standing_icons/P068_GBA_style_priest_for_holy_war
