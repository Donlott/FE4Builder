# FE4 フォーレスト斧導入パッチ - FE4 Forest Ax Introductory Patch

Category: battle

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/聖戦用パッチ・素材集 - Holy war patch-material collection/パッチ - patch/FE4 フォーレスト斧導入パッチ - FE4 Forest Ax Introductory Patch`

Installation patch may change tables/code as well as graphics; inspect patch footprint.

No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 05_Battle_animations/P039_FE4_Forest_Ax_Introductory_Patch

## Reviewed Japanese-readme finding

Forest/Hero axe patch: installation touches more than one animation system. Keep it separate from your already-patched Hero ROM until its write ranges are compared.
