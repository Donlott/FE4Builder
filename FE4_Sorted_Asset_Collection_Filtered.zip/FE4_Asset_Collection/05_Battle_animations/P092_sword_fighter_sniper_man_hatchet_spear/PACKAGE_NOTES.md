# ソードファイター・スナイパー男手斧手槍 - sword fighter sniper man hatchet spear

Category: battle

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/聖戦用パッチ・素材集 - Holy war patch-material collection/画像 - image/ソードファイター・スナイパー男手斧手槍 - sword fighter sniper man hatchet spear`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 05_Battle_animations/P092_sword_fighter_sniper_man_hatchet_spear
