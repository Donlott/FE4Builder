# 竜騎士手斧モーション - dragon knight hatchet motion

Category: battle

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4,5 リアル戦闘画像、モーション系 - FE4,5 Real battle images, motion system/竜騎士手斧モーション - dragon knight hatchet motion`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 05_Battle_animations/P022_dragon_knight_hatchet_motion
