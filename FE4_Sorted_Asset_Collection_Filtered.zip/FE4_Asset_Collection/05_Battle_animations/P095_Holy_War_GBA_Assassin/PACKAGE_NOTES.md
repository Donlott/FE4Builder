# 聖戦用GBAアサシン - Holy War GBA Assassin

Category: battle

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/聖戦用パッチ・素材集 - Holy war patch-material collection/画像 - image/聖戦用GBAアサシン - Holy War GBA Assassin`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 05_Battle_animations/P095_Holy_War_GBA_Assassin, 03_Map_movement/P095_Holy_War_GBA_Assassin, 04_Map_standing_icons/P095_Holy_War_GBA_Assassin
