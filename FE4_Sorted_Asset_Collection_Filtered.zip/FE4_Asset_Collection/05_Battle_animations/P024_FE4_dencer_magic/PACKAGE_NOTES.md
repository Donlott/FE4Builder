# FE4 dencer magic - FE4 dencer magic

Category: battle

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4,5 リアル戦闘画像、モーション系 - FE4,5 Real battle images, motion system/FE4 dencer magic - FE4 dencer magic`



- Copier-header requirement mentioned

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 05_Battle_animations/P024_FE4_dencer_magic

## Reviewed Japanese-readme finding

Dancer magic: the IPS is a demonstration. It changes Ethlyn to a dancer, gives her magic, and sets Thunder critical rate to 100; the author warns map combat was not supplied. Do not treat it as a graphics-only installation patch.
