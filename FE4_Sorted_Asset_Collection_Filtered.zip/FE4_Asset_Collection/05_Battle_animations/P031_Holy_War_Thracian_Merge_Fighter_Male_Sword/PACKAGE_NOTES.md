# 聖戦用 トラキアマージファイター男　剣魔法追加 - Holy War Thracian Merge Fighter Male Sword Magic Added

Category: battle

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4,5 リアル戦闘画像、モーション系 - FE4,5 Real battle images, motion system/聖戦用 トラキアマージファイター男　剣魔法追加 - Holy War Thracian Merge Fighter Male Sword Magic Added`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 05_Battle_animations/P031_Holy_War_Thracian_Merge_Fighter_Male_Sword
