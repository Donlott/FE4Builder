# 聖戦用改造説明資料 - Holy War Modification Explanation Materials

Category: battle

Target: FE4

Source: `FE4 ツール、資料系 - Tools, Reference Materials/聖戦用改造説明資料 - Holy War Modification Explanation Materials`



- Copier-header requirement mentioned

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 05_Battle_animations/P130_Holy_War_Modification_Explanation_Material
