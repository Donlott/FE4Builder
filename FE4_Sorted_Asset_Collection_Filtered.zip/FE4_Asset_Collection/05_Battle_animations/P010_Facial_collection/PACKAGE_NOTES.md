# 顔グラ集 - Facial collection

Category: battle

Target: FE4_or_FE5_check_readme

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4,5 顔グラ画像系 - FE4,5 Face graph image system/顔グラ集 - Facial collection`



- Shared portrait palette compatibility requires checking
- Author requests no redistribution

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 05_Battle_animations/P010_Facial_collection, 10_Maps_tilesets_backgrounds/P010_Facial_collection, 01_Portraits/P010_Facial_collection

## Reviewed Japanese-readme finding

FE45 portrait collection: mixed FE4/FE5 content; the Holy War -> Thracia subfolder is tagged FE5 donor at file level. The author permits edits but asks that the collection not be redistributed. Preserve this notice when planning any public repository.
