# ペガサス系魔法 - Pegasus magic

Category: battle

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE45_リアルアニメ関係など - FE45_Real anime related etc./FE4 - FE4/モーション制御 - motion control/ペガサス系魔法 - Pegasus magic`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 05_Battle_animations/P146_Pegasus_magic
