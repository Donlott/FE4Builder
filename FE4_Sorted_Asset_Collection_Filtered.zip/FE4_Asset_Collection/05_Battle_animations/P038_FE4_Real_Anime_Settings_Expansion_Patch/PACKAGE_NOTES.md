# FE4 リアルアニメ設定項目増設パッチ - FE4 Real Anime Settings Expansion Patch

Category: battle

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/聖戦用パッチ・素材集 - Holy war patch-material collection/パッチ - patch/FE4 リアルアニメ設定項目増設パッチ - FE4 Real Anime Settings Expansion Patch`

Installation patch may change tables/code as well as graphics; inspect patch footprint.

No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 05_Battle_animations/P038_FE4_Real_Anime_Settings_Expansion_Patch
