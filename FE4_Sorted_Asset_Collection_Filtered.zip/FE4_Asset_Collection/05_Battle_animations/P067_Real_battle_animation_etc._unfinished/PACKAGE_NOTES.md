# リアル戦闘アニメ等（未完成） - Real battle animation, etc. (unfinished)

Category: battle

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/聖戦用パッチ・素材集 - Holy war patch-material collection/画像 - image/リアル戦闘アニメ等（未完成） - Real battle animation, etc. (unfinished)`



- Contains unfinished material

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 05_Battle_animations/P067_Real_battle_animation_etc._unfinished, 01_Portraits/P067_Real_battle_animation_etc._unfinished
