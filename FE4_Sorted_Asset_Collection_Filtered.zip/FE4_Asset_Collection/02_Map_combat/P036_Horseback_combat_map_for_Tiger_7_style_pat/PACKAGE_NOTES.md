# トラ7風パッチ用騎馬マップ戦闘 - Horseback combat map for Tiger 7 style patch

Category: mapcombat

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4,5 マップアニメ画像系 - FE4,5 map anime image system/トラ7風パッチ用騎馬マップ戦闘 - Horseback combat map for Tiger 7 style patch`



- Author explicitly permits redistribution/modification

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 02_Map_combat/P036_Horseback_combat_map_for_Tiger_7_style_pat, 04_Map_standing_icons/P036_Horseback_combat_map_for_Tiger_7_style_pat

## Reviewed Japanese-readme finding

Cavalry map combat: supplied for the Thracia-style cavalry-icon patch. The readme suggests Master Knight control data for most classes and possibly Falcon Knight controls for Pegasus classes; these are author suggestions, not our emulator verification.
