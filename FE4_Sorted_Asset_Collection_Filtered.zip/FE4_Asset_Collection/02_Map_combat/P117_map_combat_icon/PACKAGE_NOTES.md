# マップ戦闘アイコン - map combat icon

Category: mapcombat

Target: FE4

Source: `FE4 ツール、資料系 - Tools, Reference Materials/バグフォグラムズ資料 - Bugfograms material/画像関連 - Image related/マップ戦闘アイコン - map combat icon`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 02_Map_combat/P117_map_combat_icon
