# FE4 トラ7風騎馬アイコンパッチ - FE4 Tiger 7 style cavalry icon patch

Category: mapcombat

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/聖戦用パッチ・素材集 - Holy war patch-material collection/パッチ - patch/FE4 トラ7風騎馬アイコンパッチ - FE4 Tiger 7 style cavalry icon patch`

Installation patch may change tables/code as well as graphics; inspect patch footprint.

No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 02_Map_combat/P040_FE4_Tiger_7_style_cavalry_icon_patch, 03_Map_movement/P040_FE4_Tiger_7_style_cavalry_icon_patch, 04_Map_standing_icons/P040_FE4_Tiger_7_style_cavalry_icon_patch
