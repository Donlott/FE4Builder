# FE4-バード_マップ戦闘・剣追加 - FE4-Bird_Map Battle・Sword Added

Category: mapcombat

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4,5 マップアニメ画像系 - FE4,5 map anime image system/FE4-バード_マップ戦闘・剣追加 - FE4-Bird_Map Battle・Sword Added`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 02_Map_combat/P035_FE4-Bird_Map_Battle_Sword_Added
