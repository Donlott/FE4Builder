# 65氏マップ戦闘グラ - Mr. 65 map battle graphics

Category: mapcombat

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4,5 マップアニメ画像系 - FE4,5 map anime image system/65氏マップ戦闘グラ - Mr. 65 map battle graphics`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 02_Map_combat/P032_Mr._65_map_battle_graphics
