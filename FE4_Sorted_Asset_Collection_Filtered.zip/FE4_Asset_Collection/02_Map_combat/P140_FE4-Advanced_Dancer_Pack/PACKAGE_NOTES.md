# FE4-上級ダンサーパック - FE4-Advanced Dancer Pack

Category: mapcombat

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4 FE-Void氏作パッチ類 - FE4 FE-Void patches/FE4-上級ダンサーパック - FE4-Advanced Dancer Pack`



- Copier-header requirement mentioned

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 02_Map_combat/P140_FE4-Advanced_Dancer_Pack, 03_Map_movement/P140_FE4-Advanced_Dancer_Pack, 04_Map_standing_icons/P140_FE4-Advanced_Dancer_Pack

## Reviewed Japanese-readme finding

Advanced Dancer pack: standing, movement and map-combat graphics split by type; the original installation patch is retained in each related category.
