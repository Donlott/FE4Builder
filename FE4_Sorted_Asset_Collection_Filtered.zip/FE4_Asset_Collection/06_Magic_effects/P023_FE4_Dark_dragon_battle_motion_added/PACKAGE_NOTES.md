# FE4 暗黒竜戦闘モーション追加 - FE4 Dark dragon battle motion added

Category: magic

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4,5 リアル戦闘画像、モーション系 - FE4,5 Real battle images, motion system/FE4 暗黒竜戦闘モーション追加 - FE4 Dark dragon battle motion added`



- Copier-header requirement mentioned

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 05_Battle_animations/P023_FE4_Dark_dragon_battle_motion_added, 06_Magic_effects/P023_FE4_Dark_dragon_battle_motion_added

## Reviewed Japanese-readme finding

Dark dragon: sprites, image-layout data, motion controls, dark-breath effect data, and program changes belong together. The battle and magic folders cross-reference this same package ID.
