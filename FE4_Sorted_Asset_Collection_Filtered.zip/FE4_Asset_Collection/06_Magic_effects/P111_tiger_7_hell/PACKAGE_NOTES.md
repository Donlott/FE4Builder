# トラ７ヘル - tiger 7 hell

Category: magic

Target: FE4

Source: `FE4 ツール、資料系 - Tools, Reference Materials/バグフォグラムズ資料 - Bugfograms material/画像関連 - Image related/トラ７ヘル - tiger 7 hell`



- Copier-header requirement mentioned

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 06_Magic_effects/P111_tiger_7_hell
