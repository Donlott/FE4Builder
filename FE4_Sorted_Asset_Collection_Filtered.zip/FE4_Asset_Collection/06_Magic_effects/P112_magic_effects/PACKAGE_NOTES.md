# 魔法エフェクト - magic effects

Category: magic

Target: FE4

Source: `FE4 ツール、資料系 - Tools, Reference Materials/バグフォグラムズ資料 - Bugfograms material/画像関連 - Image related/魔法エフェクト - magic effects`



No per-package compatibility guarantee.

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 06_Magic_effects/P112_magic_effects
