# FE4 トラ７ヘル エフェクト正常表示パッチ - FE4 Tora 7 Hell effect normal display patch

Category: magic

Target: FE4

Source: `FE4 プログラム、画像改変パッチ系 - Programs, Asset stuff/FE4 トラ７ヘル エフェクト正常表示パッチ - FE4 Tora 7 Hell effect normal display patch`



- Copier-header requirement mentioned

Original files are byte-identical copies. UTF-8 readme companions are decoded copies, not translations. Package patches may affect several assets or include demo/gameplay changes. Do not apply all patches together.

Split categories: 06_Magic_effects/P137_FE4_Tora_7_Hell_effect_normal_display_patc
